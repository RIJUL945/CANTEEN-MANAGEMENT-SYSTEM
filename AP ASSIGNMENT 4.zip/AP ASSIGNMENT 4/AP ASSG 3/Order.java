import java.util.ArrayList;

public class Order {
    private Customer customer;
    private ArrayList<CartItem> items;
    private String specialRequest;
    private boolean isVip;
    private String status;
    private boolean isCanceled;
    private boolean isRefunded;

    public Order(Customer customer, ArrayList<CartItem> items, String specialRequest, boolean isVip) {
        this.customer = customer;
        this.items = items;
        this.specialRequest = specialRequest;
        this.isVip = isVip;
        this.status = "Pending";  // Initial status
        this.isCanceled = false;
        this.isRefunded = false;
    }

    public String getItemDetails() {
        StringBuilder details = new StringBuilder();
        for (CartItem item : items) {
            details.append(item.getFood().getName())
                    .append(":")
                    .append(item.getQuantity())
                    .append(", ");
        }
        return details.length() > 0 ? details.substring(0, details.length() - 2) : ""; // Remove trailing comma
    }

    public String getSpecialRequest() {
        return specialRequest;
    }
    public String getName(){
        return customer.getName();
    }

    public String toStructuredString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Customer: ").append(customer.getName()).append("\n");
        sb.append("VIP: ").append(isVip ? "Yes" : "No").append("\n");
        sb.append("Status: ").append(status).append("\n");
        sb.append("Items:\n");
        for (CartItem item : items) {
            sb.append("- ").append(item.getFood().getName())
              .append(" x ").append(item.getQuantity())
              .append(" ($").append(item.getTotalPrice()).append(")\n");
        }
        sb.append("Special Request: ").append(specialRequest).append("\n");
        sb.append("===================================\n");
        return sb.toString();}

    public boolean placeOrder() {

        if (items == null || items.isEmpty()) {
            System.out.println("Error: Your cart is empty. Order cannot be placed.");
            return false;
        }

        // Check if any item is out of stock
        for (CartItem item : items) {
            if (!item.getFood().isAvailable()) {
                System.out.println("Error: " + item.getFood().getName() + " is out of stock. Order cannot be placed.");
                return false;
            }
        }

        this.status = "Placed";
        System.out.println("Order placed successfully.");
        return true;
    }


    public boolean isVip() {
        return isVip;
    }

    public Customer getCustomer() {
        return customer;
    }

    public ArrayList<CartItem> getItems() {
        return items;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isCanceled() {
        return isCanceled;
    }

    public void cancelOrder() {
        if (!status.equals("Preparing") && !status.equals("Completed") && !status.equals("Out for Delivery")) {
            this.isCanceled = true;
            this.status = "Canceled";
            System.out.println("Order canceled successfully.");
        } else {
            System.out.println("Order cannot be canceled as it is already " + status + ".");
        }
    }

    public boolean isRefunded() {
        return isRefunded;
    }

    public void setRefunded(boolean refunded) {
        isRefunded = refunded;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Order for " + customer.getName() + " - Status: " + status + "\nItems:\n");
        for (CartItem item : items) {
            sb.append(item).append("\n");
        }
        sb.append("Special Request: ").append(specialRequest).append("\n");
        return sb.toString();
    }

    void setSpecialRequest(String specialRequest) {
        this.specialRequest=specialRequest;
    }
}
