import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class OrdersGUI {
    private Scene scene;

    public OrdersGUI(Stage stage) {
        BorderPane layout = new BorderPane();

        // Table to display orders
        TableView<Order> ordersTable = new TableView<>();

        // Define columns
        TableColumn<Order, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Order, String> itemsColumn = new TableColumn<>("Items Ordered");
        itemsColumn.setCellValueFactory(new PropertyValueFactory<>("itemDetails"));


        TableColumn<Order, String> specialrequestColumn = new TableColumn<>("Special Request");
        specialrequestColumn.setCellValueFactory(new PropertyValueFactory<>("specialRequest"));

        TableColumn<Order, String> statusColumn = new TableColumn<>("Status");
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        ordersTable.getColumns().addAll(nameColumn, itemsColumn,specialrequestColumn, statusColumn);

        // Load data from file
        ObservableList<Order> ordersData = FXCollections.observableArrayList(MainAppData.loadPendingOrders());
        ordersTable.setItems(ordersData);

        // Buttons for navigation
        Button viewMenuButton = new Button("View Menu");
        viewMenuButton.setOnAction(e -> stage.setScene(new MenuGUI(stage).getScene()));

        HBox buttonBar = new HBox(10, viewMenuButton);

        layout.setCenter(ordersTable);
        layout.setBottom(buttonBar);

        scene = new Scene(layout, 800, 600);
    }

    public Scene getScene() {
        return scene;
    }
}
