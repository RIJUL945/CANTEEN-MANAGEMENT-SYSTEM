import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class OrderTest {

    @Test
    public void testOrderWithOutOfStockItem() {
        // Create food items
        Food pizza = new Food("Pizza", 10.99, "Main Course", true);  // In stock
        Food burger = new Food("Burger", 5.99, "Snack", false);     // Out of stock

        // Add items to the cart
        CartItem pizzaItem = new CartItem(pizza, 2);  // 2 pizzas
        CartItem burgerItem = new CartItem(burger, 1);  // 1 burger

        ArrayList<CartItem> cartItems = new ArrayList<>();
        cartItems.add(pizzaItem);
        cartItems.add(burgerItem);
        Customer customer = new Customer("Rijul", "rijul@gmail.com", "rijul123", false);

        Order order = new Order(customer, cartItems, "No special requests", customer.isVIP());

        boolean orderPlaced = order.placeOrder();

        assertFalse("Order should not be placed because one item is out of stock.", orderPlaced);
    }

    @Test
    public void testOrderWithAllInStockItems() {
        // Create food items
        Food pizza = new Food("Pizza", 10.99, "Main Course", true);  // In stock
        Food pasta = new Food("Pasta", 8.99, "Main Course", true);   // In stock

        // Add items to the cart
        CartItem pizzaItem = new CartItem(pizza, 2);  // 2 pizzas
        CartItem pastaItem = new CartItem(pasta, 1);  // 1 pasta

        ArrayList<CartItem> cartItems = new ArrayList<>();
        cartItems.add(pizzaItem);
        cartItems.add(pastaItem);

        Customer customer = new Customer("Rijul", "rijul@gmail.com", "rijul123", false);

        Order order = new Order(customer, cartItems, "No special requests", customer.isVIP());

        boolean orderPlaced = order.placeOrder();

        assertTrue("Order should be placed successfully since all items are in stock.", orderPlaced);
    }

    @Test
    public void testOrderWithEmptyCart() {
        ArrayList<CartItem> cartItems = new ArrayList<>(); // Empty cart

        Customer customer = new Customer("Rijul", "rijul@gmail.com", "rijul123", false);

        Order order = new Order(customer, cartItems, "No special requests", customer.isVIP());

        boolean orderPlaced = order.placeOrder();

        assertFalse("Order should not be placed because the cart is empty.", orderPlaced);
    }
}
