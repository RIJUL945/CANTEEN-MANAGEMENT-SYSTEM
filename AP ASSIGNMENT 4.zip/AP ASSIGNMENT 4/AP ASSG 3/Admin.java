import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Scanner;


public class Admin {
    private String name;
    private String email;
    private String password;
    private ArrayList<Order> ordersforRPG;

    public Admin(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.ordersforRPG= new ArrayList<>();
    }

    public String getEmail() { return email; }
    public String getPassword() { return password; }

    public boolean login(String email, String password) throws InvalidLoginException {
    if (this.getEmail().equals(email) && this.getPassword().equals(password)) {
        return true;
    } else {
        throw new InvalidLoginException("Invalid email or password.");
    }
}


    public void addFoodItem(ArrayList<Food> menu, String name, double price, String category) {
        menu.add(new Food(name, price, category, true));
        System.out.println("Item added");
    }

    public void updateOrderStatus(ArrayList<Order> orders, Scanner scanner) {
        if (orders.isEmpty()) {
            System.out.println("No orders available to update.");
            return;
        }

        PriorityQueue<Order> orderQueue = new PriorityQueue<>(Comparator.comparing(Order::isVip).reversed());

        orderQueue.addAll(orders);

        // Process VIP orders first
        ArrayList<Order> vipOrders = new ArrayList<>();
        ArrayList<Order> regularOrders = new ArrayList<>();
        
        while (!orderQueue.isEmpty()) {
            Order order = orderQueue.poll();
            if (order.isVip()) {
                vipOrders.add(order);
            } else {
                regularOrders.add(order);
            }
        }

        // Display and update VIP orders
        if (!vipOrders.isEmpty()) {
            System.out.println("VIP Orders:");
            for (int i = 0; i < vipOrders.size(); i++) {
                System.out.println(i + ": " + vipOrders.get(i));
            }
            System.out.print("Select an order to update by index (or -1 to skip): ");
            int index = scanner.nextInt();
            scanner.nextLine(); 

            if (index >= 0 && index < vipOrders.size()) {
                System.out.print("Enter new status (e.g., Preparing, Out for delivery, Denied, Completed): ");
                String newStatus = scanner.nextLine();
                vipOrders.get(index).setStatus(newStatus);
                if("Completed".equals(newStatus)){
                    ordersforRPG.add(vipOrders.get(index));
                    vipOrders.remove(index);
                }
                System.out.println("Order status updated to " + newStatus);
            } else if (index != -1) {
                System.out.println("Invalid order index.");
            }
        } else {
            // Display and update regular orders if no VIP orders exist
            System.out.println("No VIP orders found. Showing regular customer orders:");
            for (int i = 0; i < regularOrders.size(); i++) {
                System.out.println(i + ": " + regularOrders.get(i));
            }
            System.out.print("Select an order to update by index (or -1 to skip): ");
            int index = scanner.nextInt();
            scanner.nextLine(); 

            if (index >= 0 && index < regularOrders.size()) {
                System.out.print("Enter new status (e.g., Preparing, Out for delivery, Denied, Completed): ");
                String newStatus = scanner.nextLine();
                regularOrders.get(index).setStatus(newStatus);
                if("Completed".equals(newStatus)){
                    ordersforRPG.add(regularOrders.get(index));
                    regularOrders.remove(index);
                }
                System.out.println("Order status updated to " + newStatus);
            } else if (index != -1) {
                System.out.println("Invalid order index.");
            }
        }

        orders.clear();
        orders.addAll(vipOrders);
        orders.addAll(regularOrders);
    }

    public void processRefund(ArrayList<Order> orders, Scanner scanner) {

        ArrayList<Order> canceledOrders = new ArrayList<>();
        for (Order order : orders) {
            if (order.getStatus().equalsIgnoreCase("Canceled")) {
                canceledOrders.add(order);
            }
        }

        if (canceledOrders.isEmpty()) {
            System.out.println("No orders available to refund.");
            return;
        }

        System.out.println("Select an order to refund by index:");
        for (int i = 0; i < canceledOrders.size(); i++) {
            System.out.println(i + ": " + orders.get(i));
        }

        int index = scanner.nextInt();
        scanner.nextLine(); 

        if (index >= 0 && index < canceledOrders.size()) {
            Order order = canceledOrders.get(index);
            if (!order.isRefunded()) {
                order.setRefunded(true);
                order.setStatus("Refunded");
                System.out.println("Order refunded for customer: " + order.getCustomer().getName());
            } else {
                System.out.println("Order has already been refunded.");
            }
        } else {
            System.out.println("Invalid order index.");
        }
    }

    public void updateFoodItem(ArrayList<Food> menu, String name, double price, boolean availability) {
        for (Food food : menu) {
            if (food.getName().equalsIgnoreCase(name)) {
                food.setPrice(price);
                food.setAvailability(availability);
                System.out.println("Item updated: " + food);
                return;
            }
        }
        System.out.println("Item not found.");
    }

    public void removeFoodItem(ArrayList<Food> menu, ArrayList<Order> orders, String name) {
        menu.removeIf(food -> food.getName().equalsIgnoreCase(name));
            for (Order order : orders) {
                if (order.getStatus().equalsIgnoreCase("Pending")) {
                    for (CartItem cartItem : order.getItems()) {
                        Food food = cartItem.getFood();
                        if (food.getName().equalsIgnoreCase(name)) {
                            order.setStatus("Denied");
                            System.out.println("Order for " + order.getCustomer().getName() + " has been updated to 'Denied' due to item removal.");
                            break;
                        }
                    }
                }
            }
    }

    // Order Management
    public void viewPendingOrders(ArrayList<Order> orders) {
        boolean found = false;
        for (Order order : orders) {
            if ("Placed".equalsIgnoreCase(order.getStatus())) { // Case-insensitive comparison
                System.out.println(order);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No pending orders found.");
        }
    }
    // Report Generation
    // Report Generation
    public void generateDailySalesReport() {
        if (ordersforRPG.isEmpty()) {
            System.out.println("No completed orders to generate a report.");
            return;
        }

        int totalOrders = 0;
        double totalSales = 0;

        for (Order order : ordersforRPG) {
            if ("Completed".equalsIgnoreCase(order.getStatus())) {
                totalOrders++;
                for (CartItem cartItem : order.getItems()) {
                    Food food = cartItem.getFood();
                    int quantity = cartItem.getQuantity();
                    totalSales += food.getPrice() * quantity;
                }
            }
        }

        System.out.println("Daily Sales Report");
        System.out.println("Total Orders: " + totalOrders);
        System.out.printf("Total Sales: $%.2f%n", totalSales);
    }

}
