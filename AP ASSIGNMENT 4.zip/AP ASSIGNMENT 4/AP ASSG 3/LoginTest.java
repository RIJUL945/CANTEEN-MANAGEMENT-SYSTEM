import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.Assert.*;


public class LoginTest{
    @Test
    public void testEmail() {
        String email = "nonexistent@example.com";
        String password = "password123";
        // Main.main(new String[]{});

        // This should return false since the email doesn't exist in the file
        Customer result = Customer.login(email, password);

        // Assert that login result is null (indicating login failure)
        assertNull("Login should fail for non-existent email", result);
    }

    // Test invalid login with incorrect password
    @Test
    public void testPassword() {
        String email = "johndoe@gmail.com";
        String password = "wrongpassword";

        Customer result = Customer.login(email, password);

        // Assert that login result is null (indicating login failure)
        assertNull("Login should fail for non-existent email", result);
    }
    @Test
    public void testValidLogin() {
        String email = "johndoe@gmail.com";
        String password = "password123"; // Correct password

        // The login should succeed
        boolean loginResult = (Customer.login(email, password)!=null);

        String abc="false";
        if (loginResult) {abc="true";}
        assertTrue(abc, true);
    }
}