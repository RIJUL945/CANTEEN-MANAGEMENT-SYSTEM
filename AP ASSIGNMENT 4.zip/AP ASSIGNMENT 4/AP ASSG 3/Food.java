import java.util.ArrayList;

public class Food {
    private String name;
    private double price;
    private String category;
    private boolean isAvailable;
    private ArrayList<Review> reviews;  

    public Food(String name, double price, String category, boolean isAvailable) {
        this.name = name;
        this.price = price;
        this.category = category;
        this.isAvailable = isAvailable;
        this.reviews = new ArrayList<>();
    }

    // Getters and Setters
    public String getName() { return name; }
    public double getPrice() { return price; }
    public String getCategory() { return category; }
    public boolean isAvailable() { return isAvailable; }

    public void setPrice(double price) { this.price = price; }
    public void setAvailability(boolean available) { this.isAvailable = available; }
    public void addReview(Review review) {
        reviews.add(review);
    }
    public void viewReviews() {
        if (reviews.isEmpty()) {
            System.out.println("No reviews for this item.");
            return;
        }
        System.out.println("Reviews for " + name + ":");
        for (Review review : reviews) {
            System.out.println(review);
        }
    }

    @Override
    public String toString() {
        return name + " - $" + price + " (" + category + ") - " + (isAvailable ? "Available" : "Unavailable");
    }
}
