import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Customer {
    private String name;
    private String email;
    private String password;
    private ArrayList<Order> orderHistory;
    private boolean isVIP;
    private ArrayList<CartItem> cart;

    public Customer(String name, String email, String password, boolean isVIP) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.isVIP = isVIP;
        this.orderHistory = new ArrayList<>();
        this.cart = new ArrayList<>();
    }

    public String getName() { return name; }
    public boolean isVIP() { return isVIP; }

    public static Customer login(String email, String password) {
        String filePath = "C:\\Users\\shiwa\\Downloads\\AP ASSG 3\\AP ASSG 3\\users.txt";

        try {
            Path path = Paths.get(filePath);
            // Check if file exists
            if (!Files.exists(path)) {
                System.err.println("Error: File not found at " + filePath);
                return null;
            }
            List<String> lines = Files.readAllLines(path);

            for (String line : lines) {
                String[] userData = line.split(",");
                if (userData.length < 4) {
                    // Skip invalid entries
                    continue;
                }
                if (userData[1].equals(email) && userData[2].equals(password)) {
                    boolean isVip = Boolean.parseBoolean(userData[3]);
                    return new Customer(userData[0], userData[1], userData[2], isVip);
                }
            }
        } catch (Exception e) {
            System.err.println("An error occurred while processing the file: " + e.getMessage());
        }

        return null;
    }

    public static void register(String name, String email, String password, boolean isVip) {
        String filename = "users.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
            writer.write(name + "," + email + "," + password + "," + isVip + "\n");
            System.out.println("User registered successfully.");
        } catch (IOException e) {
            System.out.println("Error saving user data: " + e.getMessage());
        }
    }

    // Method to display user information (just for testing)
    @Override
    public String toString() {
        return "Name: " + name + ", Email: " + email + ", VIP Status: " + (isVIP ? "Yes" : "No");
    }


    public void saveOrderHistoryToFile(Order order) {
        String filename = email + "_order_history.txt";
        File file = new File(filename); // Create a File object for the filename

        try {
            // Check if the file already exists
            if (!file.exists()) {
                // If the file does not exist, create a new one
                file.createNewFile();
                System.out.println("Order history file created: " + filename);
            }

            // Append the new order to the existing file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
                writer.write(order.toStructuredString() + "\n");
                System.out.println("Order saved to history.");
            }
        } catch (IOException e) {
            System.out.println("Error saving order history: " + e.getMessage());
        }
    }

    public void displayOrderHistoryFromFile() {
        String filename = email + "_order_history.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            System.out.println("Order History for " + name + ":");
            while ((line = reader.readLine()) != null) {
                System.out.println(line); // Display each line (order entry) from the file
            }
        } catch (FileNotFoundException e) {
            System.out.println("No order history found for " + name); // File doesn't exist yet
        } catch (IOException e) {
            System.out.println("Error reading order history: " + e.getMessage());
        }
    }


    public void addItemToCart(ArrayList<Food> menu, Scanner scanner) {
        System.out.print("Enter the name of the item you want to add: ");
        String itemName = scanner.nextLine();
        Food selectedFood = null;

        for (Food food : menu) {
            if (food.getName().equalsIgnoreCase(itemName)) {
                selectedFood = food;
                break;
            }
        }

        if (selectedFood != null) {
            System.out.print("Enter quantity: ");
            int quantity = scanner.nextInt();
            scanner.nextLine(); 
            cart.add(new CartItem(selectedFood, quantity));
            System.out.println(quantity + " x " + selectedFood.getName() + " added to the cart.");
            viewCartTotal(); 
        } else {
            System.out.println("Item not found.");
        }
    }

    public void updateCart(Scanner scanner, ArrayList<Food> menu) {
    while (true) {
        System.out.println("\nUpdate Cart Options:");
        System.out.println("1. Add more items");
        System.out.println("2. Remove an item");
        System.out.println("3. Change quantity of an item");
        System.out.println("4. Back to main menu");
        String choice = scanner.nextLine();

        if (choice.equals("1")) {
            addItemToCart(menu, scanner);
        } else if (choice.equals("2")) {
            removeItemFromCart(scanner);
        } else if (choice.equals("3")) {
            modifyCartItemQuantity(scanner);
        } else if (choice.equals("4")) {
            break;
        } else {
            System.out.println("Invalid option. Please try again.");
        }
    }
}


    // Method to modify quantities of items in the cart
    public void modifyCartItemQuantity(Scanner scanner) {
        System.out.print("Enter the name of the item to modify: ");
        String itemName = scanner.nextLine();

        for (CartItem cartItem : cart) {
            if (cartItem.getFood().getName().equalsIgnoreCase(itemName)) {
                System.out.print("Enter new quantity: ");
                int newQuantity = scanner.nextInt();
                scanner.nextLine();
                cartItem.setQuantity(newQuantity);
                System.out.println("Quantity updated to " + newQuantity + " for " + itemName);
                return;
            }
        }
        System.out.println("Item not found in cart.");
    }

    // Method to remove items from the cart
    public void removeItemFromCart(Scanner scanner) {
        System.out.print("Enter the name of the item to remove: ");
        String itemName = scanner.nextLine();

        for (CartItem cartItem : cart) {
            if (cartItem.getFood().getName().equalsIgnoreCase(itemName)) {
                cart.remove(cartItem);
                System.out.println(itemName + " removed from cart.");
                return;
            }
        }
        System.out.println("Item not found in cart.");
    }

    // Method to view the total price of items in the cart
    public void viewCartTotal() {
        double total = 0;
        System.out.println("Items in your cart:");
        for (CartItem cartItem : cart) {
            System.out.println(cartItem);
            total += cartItem.getTotalPrice();
        }
        System.out.println("Total price: $" + total);
    }

    // Method to place an order
public void placeOrder(Scanner scanner) {
    if (cart.isEmpty()) {
        System.out.println("Your cart is empty. Add items before placing an order.");
        return;
    }

    System.out.println("Your Cart:");
    viewCartTotal();

    // Ask for confirmation
    System.out.print("Do you want to place the order? (yes/no): ");
    String confirm = scanner.nextLine();

    if (confirm.equalsIgnoreCase("yes")) {
        Order order = new Order(this, new ArrayList<>(cart), "", isVIP); 
        boolean isOrderValid = order.placeOrder();  

        if (isOrderValid) {
            System.out.print("Enter special requests (if any): ");
            String specialRequest = scanner.nextLine();

            // Create a new order from the cart
            order.setSpecialRequest(specialRequest);
            orderHistory.add(order);


            Main.orders.add(order); 
            System.out.print("Enter payment details: ");
            String paymentDetails = scanner.nextLine();
            System.out.print("Enter delivery address: ");
            String deliveryAddress = scanner.nextLine();

            System.out.println("Order placed successfully!");
            saveOrderHistoryToFile(order);
            System.out.println("Payment details: " + paymentDetails);
            System.out.println("Delivery address: " + deliveryAddress);
            cart.clear();  
        } else {
            System.out.println("Order cannot be placed due to out-of-stock items.");
        }
    } else {
        System.out.println("Order not placed.");
    }
}

    public void viewAllItems(ArrayList<Food> menu) {
        System.out.println("Menu Items:");
        for (Food food : menu) {
            System.out.println(food);
        }
    }

    public void searchItems(ArrayList<Food> menu, String keyword) {
        System.out.println("Search results for '" + keyword + "':");
        for (Food food : menu) {
            if (food.getName().toLowerCase().contains(keyword.toLowerCase())) {
                System.out.println(food);
            }
            else{
                System.out.println("ITEM NOT FOUND");
            }
        }
    }

    // Method to filter items by category
    public void filterByCategory(ArrayList<Food> menu, String category) {
        System.out.println("Items in category '" + category + "':");
        for (Food food : menu) {
            if (food.getCategory().equalsIgnoreCase(category)) {
                System.out.println(food);
            }else{
                System.out.println("CATEGORY NOT FOUND");
            }
        }
    }

    // Method to sort items by price
    public void sortByPrice(ArrayList<Food> menu, boolean ascending) {
        menu.sort(new Comparator<Food>() {
            @Override
            public int compare(Food f1, Food f2) {
                return ascending ? Double.compare(f1.getPrice(), f2.getPrice()) : Double.compare(f2.getPrice(), f1.getPrice());
            }
        });

        // Display sorted menu
        System.out.println("Menu sorted by price (" + (ascending ? "ascending" : "descending") + "):");
        for (Food food : menu) {
            System.out.println(food);
        }
    }

    public void viewOrderStatus() {
        System.out.println("Current Orders:");
        for (Order order : orderHistory) {
            if (!order.isCanceled()) {
                System.out.println(order);
            }
        }
    }

    // Method to cancel an order
    public void cancelOrder(Scanner scanner) {
        System.out.println("Select an order to cancel by index:");
        for (int i = 0; i < orderHistory.size(); i++) {
            Order order = orderHistory.get(i);
            if (!order.isCanceled() && !order.getStatus().equals("Completed")) {
                System.out.println(i + ": " + order);
            }
        }

        int index = scanner.nextInt();
        scanner.nextLine(); 

        if (index >= 0 && index < orderHistory.size()) {
            Order order = orderHistory.get(index);
            order.cancelOrder();
        } else {
            System.out.println("Invalid order index.");
        }
    }

    public void reorder(Scanner scanner) {
        System.out.println("Select a past order to reorder by index:");
        for (int i = 0; i < orderHistory.size(); i++) {
            Order order = orderHistory.get(i);
            System.out.println(i + ": " + order);
        }

        int index = scanner.nextInt();
        scanner.nextLine(); 

        if (index >= 0 && index < orderHistory.size()) {
            Order pastOrder = orderHistory.get(index);
            this.cart.clear();
            this.cart.addAll(pastOrder.getItems());
            System.out.println("Items from selected order have been added to your cart.");
            placeOrder(scanner);  
        } else {
            System.out.println("Invalid order index.");
        }
    }

    public void provideReview(Scanner scanner) {
        System.out.println("Leave a Review - Select an order:");
        ArrayList<Food> orderedItems = new ArrayList<>();

        // List all past orders and gather ordered items
        for (Order order : orderHistory) {
            if (order.getStatus().equals("Completed")) {
                for (CartItem cartItem : order.getItems()) {
                    if (!orderedItems.contains(cartItem.getFood())) {
                        orderedItems.add(cartItem.getFood());
                    }
                }
            } else{ System.out.println(" CANT REVIEW THE FOOD " );
            break;}
        }

        // Show ordered items and select one to review
        for (int i = 0; i < orderedItems.size(); i++) {
            System.out.println(i + ": " + orderedItems.get(i).getName());
        }

        System.out.print("Enter the index of the item you want to review: ");
        int index = scanner.nextInt();
        scanner.nextLine(); 

        if (index >= 0 && index < orderedItems.size()) {
            Food foodItem = orderedItems.get(index);

            System.out.print("Enter your rating (1-5): ");
            int rating = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter your review text: ");
            String reviewText = scanner.nextLine();

            // Create and add the review
            Review review = new Review(this.getName(), reviewText, rating);
            foodItem.addReview(review);

            System.out.println("Review added for " + foodItem.getName());
        } else {
            System.out.println("Invalid selection.");
        }
    }

    // Method to view reviews for a particular item
    public void viewReviews(ArrayList<Food> menu, Scanner scanner) {
        System.out.print("Enter the name of the food item to view reviews: ");
        String itemName = scanner.nextLine();
        Food selectedFood = null;

        for (Food food : menu) {
            if (food.getName().equalsIgnoreCase(itemName)) {
                selectedFood = food;
                break;
            }
        }

        if (selectedFood != null) {
            selectedFood.viewReviews();
        } else {
            System.out.println("Item not found.");
        }
    }

    public void purchaseVIPMembership(Scanner scanner) {
        System.out.println("VIP membership price: $5 for a month");
        System.out.print("Wanna proceed and buy the membership? (yes/no): ");
        
        String decision = scanner.nextLine();
        if (decision.equalsIgnoreCase("yes")) {
            System.out.print("Enter card number: ");
            String cardNumber = scanner.nextLine();
            
            System.out.print("Enter card PIN: ");
            String cardPin = scanner.nextLine();

            this.isVIP = true;
            System.out.println("Congratulations! You are now a VIP member.");
            System.out.println("Thank you for purchasing VIP membership.");
        } else {
            System.out.println("Returning to the menu.");
        }
    }


    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }
}
