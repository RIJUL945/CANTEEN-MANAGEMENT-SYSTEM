import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class MenuGUI {
    private Scene scene;

    public MenuGUI(Stage stage) {
        BorderPane layout = new BorderPane();

        // Table to display menu
        TableView<Food> menuTable = new TableView<>();

        // Define columns
        TableColumn<Food, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Food, Double> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<Food, String> categoryColumn = new TableColumn<>("Category");
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));

        TableColumn<Food, String> availabilityColumn = new TableColumn<>("Availability");
        availabilityColumn.setCellValueFactory(cellData -> {
            boolean isAvailable = cellData.getValue().isAvailable(); // Bind to isAvailable()
            return new SimpleStringProperty(isAvailable ? "Available" : "Out of Stock");
        });


        menuTable.getColumns().addAll(nameColumn, priceColumn,categoryColumn, availabilityColumn);

        // Load data from file
        ObservableList<Food> menuData = FXCollections.observableArrayList(MainAppData.loadMenu());
        menuTable.setItems(menuData);

        // Buttons for navigation
        Button viewOrdersButton = new Button("View Orders");
        viewOrdersButton.setOnAction(e -> stage.setScene(new OrdersGUI(stage).getScene()));

        HBox buttonBar = new HBox(10, viewOrdersButton);

        layout.setCenter(menuTable);
        layout.setBottom(buttonBar);

        scene = new Scene(layout, 800, 600);
    }

    public Scene getScene() {
        return scene;
    }
}
