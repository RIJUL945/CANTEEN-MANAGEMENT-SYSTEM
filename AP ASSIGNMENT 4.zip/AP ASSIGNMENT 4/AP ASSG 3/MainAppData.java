import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class MainAppData {
    public static final String MENU_FILE = "C:\\Users\\shiwa\\Downloads\\AP ASSG 3\\AP ASSG 3\\menu.txt";
    private static final String ORDERS_FILE = "C:\\Users\\shiwa\\Downloads\\AP ASSG 3\\AP ASSG 3\\orders.txt";

    // Load menu data from file
    public static List<Food> loadMenu() {
        List<Food> menu = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(MENU_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) { // Ensure valid format
                    String name = parts[0].trim();
                    double price = Double.parseDouble(parts[1].trim());
                    String category = parts[2].trim();
                    boolean isAvailable = Boolean.parseBoolean(parts[3].trim());
                    menu.add(new Food(name, price, category,isAvailable));
                } else {
                    System.out.println("Invalid menu entry: " + line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading menu data: " + e.getMessage());
        }
        return menu;
    }

    // Load pending orders from file
    public static List<Order> loadPendingOrders() {
        List<Order> orders = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(ORDERS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 4) {
                    // Parse customer details
                    String[] customerDetails = parts[0].split(",");
                    if (customerDetails.length == 4) {
                        String customerName = customerDetails[0].trim();
                        String customerEmail = customerDetails[1].trim();
                        String customerPass = customerDetails[2].trim();
                        boolean isVIP = Boolean.parseBoolean(customerDetails[3].trim());
                        Customer customer = new Customer(customerName, customerEmail, customerPass, isVIP);

                        // Parse items
                        ArrayList<CartItem> items = new ArrayList<>();
                        String[] itemDetails = parts[1].split(",");
                        for (String item : itemDetails) {
                            String[] itemParts = item.split(":");
                            if (itemParts.length == 2) {
                                String itemName = itemParts[0].trim();
                                int quantity = Integer.parseInt(itemParts[1].trim());
                                Food food = new Food(itemName, 0.0, "", true); // Replace with actual price lookup if needed
                                items.add(new CartItem(food, quantity));
                            }
                        }

                        // Parse special request
                        String specialRequest = parts[2].trim();
                        String status = parts[3].trim();


                        // Create and add the order
                        Order order = new Order(customer, items, specialRequest, isVIP);
                        order.setStatus(status);
                        orders.add(order);
                    } else {
                        System.out.println("Invalid customer details in order: " + parts[0]);
                    }
                } else {
                    System.out.println("Invalid order entry: " + line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading orders data: " + e.getMessage());
        }
        return orders;
    }

    public static void saveOrders(List<Order> orders) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ORDERS_FILE, false))) {
            for (Order order : orders) {
                Customer customer = order.getCustomer();
                StringBuilder itemsBuilder = new StringBuilder();
                for (CartItem item : order.getItems()) {
                    itemsBuilder.append(item.getFood().getName())
                            .append(":")
                            .append(item.getQuantity())
                            .append(",");
                }

                String items = itemsBuilder.length() > 0 ? itemsBuilder.substring(0, itemsBuilder.length() - 1) : "";

                writer.printf("%s,%s,%s,%b;%s;%s;%s%n",
                        customer.getName(),
                        customer.getEmail(),
                        customer.getPassword(),
                        customer.isVIP(),
                        items,
                        order.getSpecialRequest(),
                        order.getStatus()
                );
            }
            System.out.println("Orders saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving orders: " + e.getMessage());
        }
    }


}
