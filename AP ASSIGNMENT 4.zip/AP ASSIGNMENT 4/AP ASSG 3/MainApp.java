import javafx.application.Application;
import javafx.stage.Stage;

public class MainApp extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Start with the Menu GUI
        MenuGUI menuGUI = new MenuGUI(primaryStage);
        primaryStage.setTitle("Canteen Management System");
        primaryStage.setScene(menuGUI.getScene());
        primaryStage.show();
    }

    public static void main(String[] args) {
        CanteenCLI cli = new CanteenCLI();
        cli.start();

        launch(args);
    }
}

