import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Scanner;
import java.util.*;

public class CanteenCLI {
    private Scanner scanner = new Scanner(System.in);

    public void start() {
        boolean running = true;

        while (running) {
            System.out.println("..... Canteen CLI......");
            System.out.println("1. View Menu");
            System.out.println("2. Add Food Item");
            System.out.println("3. View Orders");
            System.out.println("4. Place an Order");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> viewMenu();
                case 2 -> addFoodItem();
                case 3 -> viewOrders();
                case 4 -> placeOrder();
                case 5 -> running = false;
                default -> System.out.println("Invalid choice. Try again.");
            }
        }
        System.out.println("Exiting CLI...");
    }

    private void viewMenu() {
        System.out.println("..... Menu .....");
        for (Food food : MainAppData.loadMenu()) {
            System.out.println(food);
        }
    }

    private void addFoodItem() {
        System.out.println("..... Add Food Item .....");
        System.out.print("Enter food name: ");
        String name = scanner.nextLine();
        System.out.print("Enter price: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter category: ");
        String category = scanner.nextLine();
        System.out.print("Is the item available? (true/false): ");
        boolean isAvailable = scanner.nextBoolean();
        scanner.nextLine(); // Consume newline

        Food newFood = new Food(name, price, category, isAvailable);
        List<Food> menu = MainAppData.loadMenu();
        menu.add(newFood);

        // Save to file
        try (PrintWriter writer = new PrintWriter(new FileWriter(MainAppData.MENU_FILE, false))) {
            for (Food food : menu) {
                writer.printf("%s,%.2f,%s,%b%n", food.getName(), food.getPrice(), food.getCategory(), food.isAvailable());
            }
            System.out.println("Food item added successfully.");
        } catch (IOException e) {
            System.out.println("Error saving menu: " + e.getMessage());
        }
    }

    private void placeOrder() {
        System.out.println("..... Place an Order .....");

        // Load menu
        List<Food> menu = MainAppData.loadMenu();
        if (menu.isEmpty()) {
            System.out.println("Menu is empty. Cannot place an order.");
            return;
        }

        System.out.println("Menu:");
        for (int i = 0; i < menu.size(); i++) {
            Food food = menu.get(i);
            System.out.println((i + 1) + ". " + food.getName() + " - $" + food.getPrice() + " (" + (food.isAvailable() ? "Available" : "Out of Stock") + ")");
        }

        System.out.print("Enter customer name: ");
        String customerName = scanner.nextLine();
        System.out.print("Enter customer email: ");
        String customerEmail = scanner.nextLine();
        System.out.print("Enter customer password: ");
        String customerPass = scanner.nextLine();
        System.out.print("Is the customer a VIP? (true/false): ");
        boolean isVIP = scanner.nextBoolean();
        scanner.nextLine();

        Customer customer = new Customer(customerName, customerEmail, customerPass, isVIP);

        ArrayList<CartItem> cartItems = new ArrayList<>();
        while (true) {
            System.out.print("Enter menu item number to add (or 0 to finish): ");
            int itemNumber = scanner.nextInt();
            if (itemNumber == 0) break;
            if (itemNumber < 1 || itemNumber > menu.size()) {
                System.out.println("Invalid item number. Try again.");
                continue;
            }

            Food selectedFood = menu.get(itemNumber - 1);
            if (!selectedFood.isAvailable()) {
                System.out.println(selectedFood.getName() + " is out of stock. Please choose another item.");
                continue;
            }

            System.out.print("Enter quantity: ");
            int quantity = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Enter any special request (or press Enter to skip): ");
            String specialRequest = scanner.nextLine();

            cartItems.add(new CartItem(selectedFood, quantity));

            Order newOrder = new Order(customer, cartItems, specialRequest, isVIP);
            newOrder.setStatus("Pending");
            List<Order> orders = MainAppData.loadPendingOrders();
            orders.add(newOrder);
            MainAppData.saveOrders(orders);
        }
        System.out.println("Order placed successfully.");
    }


    private void viewOrders() {
        System.out.println("..... Orders .....");
        for (Order order : MainAppData.loadPendingOrders()) {
            System.out.println(order);
        }
    }
}
