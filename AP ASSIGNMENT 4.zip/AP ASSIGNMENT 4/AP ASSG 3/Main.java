import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static ArrayList<Order> orders = new ArrayList<>();
    public static void main(String[] args) {
        ArrayList<Food> menu = new ArrayList<>();
        ArrayList<Customer> customers = new ArrayList<>();
        ArrayList<Admin> admins = new ArrayList<>();

        Scanner scanner = new Scanner(System.in);

        // Initialize sample data
        admins.add(new Admin("Admin", "admin@byte.com", "admin123"));
        customers.add(new Customer("RIJUL", "rijul@gmail.com", "rijul123", false));
        customers.add(new Customer("VATSAL", "vatsal@gmail.com", "vatsal123", true));

        Admin admin = admins.get(0); 
                while (true) {
            System.out.println("1. Login as Admin\n2. Login as Customer\n3. Sign Up as Customer\n4. Exit");
            String choice = scanner.nextLine();

            if (choice.equals("1")) {
                try {
                    System.out.print("Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Password: ");
                    String password = scanner.nextLine();
                    if (admin.login(email, password)) {
                        adminMenu(scanner, admin, menu, orders);
                    }
                } catch (InvalidLoginException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            } else if (choice.equals("2")) {
                customerMenu(scanner, customers, menu, orders);
            } else if (choice.equals("3")) {
                System.out.print("Enter Name: ");
                String name = scanner.nextLine();
                System.out.print("Enter Email: ");
                String email = scanner.nextLine();
                System.out.print("Enter Password: ");
                String password = scanner.nextLine();
                boolean isVip = Boolean.parseBoolean(scanner.nextLine());
                Customer.register(name, email, password, isVip);
                customers.add(new Customer(name, email, password, false));
                System.out.println("Customer account created successfully.");
            } else if (choice.equals("4")) {
                break;
            } else {
                System.out.println("Invalid option. Please choose again.");
            }
        }
        scanner.close();
    }
    public static void adminMenu(Scanner scanner, Admin admin, ArrayList<Food> menu, ArrayList<Order> orders) {
        while (true) {
            System.out.println("\nAdmin Menu\n1. Add Food\n2. Update Food\n3. Remove Food\n4. View Orders\n5. Daily Report\n6. Update Order Status\n7. Process Refund\n8. Logout");
            String choice = scanner.nextLine();

            if (choice.equals("1")) {
                System.out.print("Name: ");
                String name = scanner.nextLine();
                System.out.print("Price: ");
                double price = scanner.nextDouble();
                scanner.nextLine();
                System.out.print("Category: ");
                String category = scanner.nextLine();
                admin.addFoodItem(menu, name, price, category);
            } else if (choice.equals("2")) {
                System.out.print("Name of item to update: ");
                String name = scanner.nextLine();
                System.out.print("New price: ");
                double price = scanner.nextDouble();
                scanner.nextLine();
                System.out.print("Availability (true/false): ");
                boolean availability = scanner.nextBoolean();
                scanner.nextLine();
                admin.updateFoodItem(menu, name, price, availability);
            } else if (choice.equals("3")) {
                System.out.print("Name of item to remove: ");
                String name = scanner.nextLine();
                admin.removeFoodItem(menu, orders, name);
            } else if (choice.equals("4")) {
                admin.viewPendingOrders(orders);
            } else if (choice.equals("5")) {
                admin.generateDailySalesReport();
            } else if (choice.equals("6")){
                admin.updateOrderStatus(orders, scanner);
            }else if (choice.equals("7")){
                admin.processRefund(orders, scanner);
            }else if (choice.equals("8")){
                break;
            }
        }
    }

    public static void customerMenu(Scanner scanner, ArrayList<Customer> customers, ArrayList<Food> menu, ArrayList<Order> orders) {
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();
        Customer loggedInCustomer = Customer.login(email, password);
        try{

            if (loggedInCustomer != null) {
                System.out.println("Welcome, " + loggedInCustomer.getName() + " to BYTE ME!");
                while (true) {
                    System.out.println("\nCustomer Menu");
                    System.out.println("1. View All Items");
                    System.out.println("2. Search for an Item");
                    System.out.println("3. Filter by Category");
                    System.out.println("4. Sort by Price");
                    System.out.println("5. Add Items to Cart");
                    System.out.println("6. Update Cart");
                    System.out.println("7. Place Order");
                    System.out.println("8. View Order Status");
                    System.out.println("9. Cancel Order");
                    System.out.println("10. View Order History");
                    System.out.println("11. Reorder from History");
                    System.out.println("12. Provide Review");
                    System.out.println("13. View Reviews of an Item");
                    System.out.println("14. Become a VIP");
                    System.out.println("15. Logout");
                    String choice = scanner.nextLine();
                    if (choice.equals("1")) {
                        loggedInCustomer.viewAllItems(menu);
                    } else if (choice.equals("2")) {
                        System.out.print("Enter keyword to search: ");
                        String keyword = scanner.nextLine();
                        loggedInCustomer.searchItems(menu, keyword);
                    } else if (choice.equals("3")) {
                        System.out.print("Enter category to filter: ");
                        String category = scanner.nextLine();
                        loggedInCustomer.filterByCategory(menu, category);
                    } else if (choice.equals("4")) {
                        System.out.print("Sort by price in ascending order? (yes/no): ");
                        boolean ascending = scanner.nextLine().equalsIgnoreCase("yes");
                        loggedInCustomer.sortByPrice(menu, ascending);
                    } else if (choice.equals("5")) {
                        loggedInCustomer.addItemToCart(menu, scanner);
                    } else if (choice.equals("6")) {
                        loggedInCustomer.updateCart(scanner, menu); // Pass menu as a parameter here
                    } else if (choice.equals("7")) {
                        loggedInCustomer.placeOrder(scanner);
                    }else if (choice.equals("8")) {
                        loggedInCustomer.viewOrderStatus();
                    }else if (choice.equals("9")) {
                        loggedInCustomer.cancelOrder(scanner);
                    }else if (choice.equals("10")) {
                        loggedInCustomer.displayOrderHistoryFromFile();
                    }else if (choice.equals("11")) {
                        loggedInCustomer.reorder(scanner);
                    }else if (choice.equals("12")) {
                        loggedInCustomer.provideReview(scanner);
                    }else if (choice.equals("13")) {
                        loggedInCustomer.viewReviews(menu, scanner);
                    }else if (choice.equals("14")) {
                        loggedInCustomer.purchaseVIPMembership(scanner);
                    }else if (choice.equals("15")) {
                        break;
                    }
                     else {
                        System.out.println("Invalid option. Please try again.");
                    }
                }
            }

            throw new InvalidLoginException("Invalid email or password.");
            }catch (InvalidLoginException e) {
                System.out.println("Error: " + e.getMessage());
                return;
            }
                }
            }
        